import sys
import os
import tempfile
import re

if len(sys.argv) < 2:
    print("Usage: script_name.py <input_file.gcode>")
    sys.exit(1)

sourceFile = sys.argv[1] 

# Logic constants
SUPPORT_TYPE = "_SET_SUPP"
CHECK_INTERVAL_CALL = "_CHECK_INTERVAL"
SET_INTERVAL_CALL = "_SET_INTERVAL_VARIABLES"
SKIP_CALL = "_INTERVAL_SKIP" 

# Split Bridge and Overhang types
BRIDGE_TYPES = [";TYPE:Bridge", ";TYPE:Internal Bridge"]
BW_TYPES = [";TYPE:Overhang wall"]

# Updated Regex to include Overhang wall as a specific excluded type for support logic
OTHER_TYPES_PATTERN = re.compile(r";TYPE:(?!Support|Bridge|Internal Bridge|Overhang wall)") 

FLOW_REDUCE_TYPES = [";TYPE:Top surface", ";TYPE:Internal solid infill"]
STRIP_COMMANDS = ("M104", "M109", "M140", "M190")

# States
current_state = 0 
in_bridge_mode = False 
in_bw_mode = False
in_flow_reduce_mode = False

temp_file_final = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix=".gcode")

with open(sourceFile, "r") as f_in:
    for line in f_in:
        # --- TEMPERATURE STRIPPING LOGIC ---
        if line.strip().startswith(STRIP_COMMANDS):
            continue

        # --- BRIDGE LOGIC (Minus Overhang) ---
        if in_bridge_mode and (";LAYER_CHANGE" in line or (";TYPE:" in line and not any(b_type in line for b_type in BRIDGE_TYPES))):
            temp_file_final.write("_RESET_BRIDGE_PARAMS\n")
            in_bridge_mode = False
        if any(b_type in line for b_type in BRIDGE_TYPES):
            if not in_bridge_mode:
                temp_file_final.write("_SET_BRIDGE_PARAMS\n")
                in_bridge_mode = True

        # --- NEW OVERHANG WALL LOGIC ---
        if in_bw_mode and (";LAYER_CHANGE" in line or (";TYPE:" in line and not any(o_type in line for o_type in BW_TYPES))):
            temp_file_final.write("_RESET_BW\n")
            in_bw_mode = False
        if any(o_type in line for o_type in BW_TYPES):
            if not in_bw_mode:
                temp_file_final.write("_SET_BW\n")
                in_bw_mode = True

        # --- FLOW REDUCTION LOGIC (Unchanged) ---
        if in_flow_reduce_mode:
            is_new_type = ";TYPE:" in line
            is_targeted_type = any(f_type in line for f_type in FLOW_REDUCE_TYPES)
            if ";LAYER_CHANGE" in line or (is_new_type and not is_targeted_type):
                temp_file_final.write("_FLOW_RESTORE\n")
                in_flow_reduce_mode = False

        if any(f_type in line for f_type in FLOW_REDUCE_TYPES):
            if not in_flow_reduce_mode:
                temp_file_final.write("_FLOW_REDUCE\n")
                in_flow_reduce_mode = True
        
        # --- SUPPORT SKIP LOGIC (Unchanged) ---
        if current_state == 1 and OTHER_TYPES_PATTERN.search(line):
            current_state = 0
        if SUPPORT_TYPE in line and current_state == 0:
            current_state = 1 
        if CHECK_INTERVAL_CALL in line:
            if current_state == 1:
                new_commands = f"{SET_INTERVAL_CALL}\n{SKIP_CALL}\n"
                line = line.replace(CHECK_INTERVAL_CALL, new_commands)
            current_state = 0

        temp_file_final.write(line)

# Cleanup
if in_bridge_mode: temp_file_final.write("_RESET_BRIDGE_PARAMS\n")
if in_bw_mode: temp_file_final.write("_RESET_BW\n")
if in_flow_reduce_mode: temp_file_final.write("_FLOW_RESTORE\n")

temp_file_final.close()
os.replace(temp_file_final.name, sourceFile)
