#!/bin/sh

VARS="/home/sonic/klipper/variables.cfg"
CFG="/home/sonic/printer_data/config/kg_os_pro_filupd.cfg"

act_ext_target=$(grep '^act_ext_target = ' "$VARS" | awk '{print $3}')
act_bed_target=$(grep '^act_bed_target = ' "$VARS" | awk '{print $3}')
act_bottom_flow=$(grep '^act_bottom_flow = ' "$VARS" | awk '{print $3}')
act_solid_flow=$(grep '^act_solid_flow = ' "$VARS" | awk '{print $3}')
act_bridge_wall_flow=$(grep '^act_bridge_wall_flow = ' "$VARS" | awk '{print $3}')
act_ohw_flow=$(grep '^act_ohw_flow = ' "$VARS" | awk '{print $3}')
act_norm_fan=$(grep '^act_norm_fan = ' "$VARS" | awk '{print $3}')
act_solid_fan=$(grep '^act_solid_fan = ' "$VARS" | awk '{print $3}')
act_bridge_fan=$(grep '^act_bridge_fan = ' "$VARS" | awk '{print $3}')
act_bridge_wall_fan=$(grep '^act_bridge_wall_fan = ' "$VARS" | awk '{print $3}')
act_ohw_fan=$(grep '^act_ohw_fan = ' "$VARS" | awk '{print $3}')
act_supp_int_fan=$(grep '^act_supp_int_fan = ' "$VARS" | awk '{print $3}')
act_ohw_accel=$(grep '^act_ohw_accel = ' "$VARS" | awk '{print $3}')
act_ohw_flow=$(grep '^act_ohw_flow = ' "$VARS" | awk '{print $3}')
act_bridge_jerk=$(grep '^act_bridge_jerk = ' "$VARS" | awk '{print $3}')
act_ohw_jerk=$(grep '^act_ohw_jerk = ' "$VARS" | awk '{print $3}')
act_min_layer_time=$(grep '^act_min_layer_time = ' "$VARS" | awk '{print $3}')

sed -Ei '/# Filament Update Section Start/,/# Filament Update Section End/{
s@(\{% set ext_target = params\.EXT_TEMP\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_ext_target"'\2@
s@(\{% set bed_target = params\.BED_TEMP\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bed_target"'\2@
s@(\{% set bottom_flow = params\.BOTTOM_FLOW\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bottom_flow"'\2@
s@(\{% set solid_flow = params\.SOLID_FLOW\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_solid_flow"'\2@
s@(\{% set bridge_wall_flow = params\.BRIDGE_WALL_FLOW\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bridge_wall_flow"'\2@
s@(\{% set ohw_flow = params\.OH_WALL_FLOW\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_ohw_flow"'\2@
s@(\{% set norm_fan = params\.NORM_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_norm_fan"'\2@
s@(\{% set solid_fan = params\.SOLID_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_solid_fan"'\2@
s@(\{% set bridge_fan = params\.BRIDGE_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bridge_fan"'\2@
s@(\{% set bridge_wall_fan = params\.BRIDGE_WALL_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bridge_wall_fan"'\2@
s@(\{% set ohw_fan = params\.OH_WALL_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_ohw_fan"'\2@
s@(\{% set supp_int_fan = params\.SUPPORT_INT_FAN\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_supp_int_fan"'\2@
s@(\{% set ohw_accel = params\.OH_WALL_ACCEL\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_ohw_accel"'\2@
s@(\{% set bridge_jerk = params\.BRIDGE_JERK\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_bridge_jerk"'\2@
s@(\{% set ohw_jerk = params\.OH_WALL_JERK\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_ohw_jerk"'\2@
s@(\{% set min_layer_time = params\.MIN_LAYER_TIME\|default\()[0-9]*(\)\|int != 0 %})@\1'"$act_min_layer_time"'\2@
}' "$CFG"

