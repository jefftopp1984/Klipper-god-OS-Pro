#!/bin/bash
set -e

VARS="/home/sonic/klipper/variables.cfg"
CFG="/home/sonic/printer_data/config/kg_os_pro_filchng.cfg"
TMP="/tmp/kg_os_pro_filchng.tmp"

INDENT="        "

# read new filament name and abbreviation
fil_new=$(awk -F' = ' "/^fil_new =/ {gsub(/'/,\"\",\$2); print \$2}" "$VARS")
abb_new=$(awk -F' = ' "/^abb_new =/ {gsub(/'/,\"\",\$2); print \$2}" "$VARS")

[ -z "$fil_new" ] && exit 1
[ -z "$abb_new" ] && exit 1

new_line="RESPOND TYPE=command MSG=\"action:prompt_button ${fil_new}|_SELECT_FILAMENT ABB=${abb_new}|secondary\""

awk -v newline="$new_line" -v indent="$INDENT" '
/action:prompt_group_begin/ {
    print
    in_group=1
    next
}

/action:prompt_group_end/ {
    buttons[newline]=1
    for (b in buttons) print indent b | "sort"
    close("sort")
    delete buttons
    in_group=0
    print
    next
}

in_group && /action:prompt_button / {
    sub(/^ +/,"",$0)
    buttons[$0]=1
    next
}

{ print }
' "$CFG" > "$TMP"

mv "$TMP" "$CFG"
