#!/bin/bash
set -e

VARS="/home/sonic/klipper/variables.cfg"
CFG="/home/sonic/printer_data/config/kg_os_pro_filchng.cfg"
TMP_CFG="/tmp/kg_os_pro_filchng.tmp"
TMP_VARS="/tmp/variables.tmp"
INDENT="    "

# read filament abbreviation to delete (FORMAT: abb_delete = 'asacf')
abb_delete=$(awk -F' = ' "/^abb_delete =/ {gsub(/'/, \"\", \$2); print \$2}" "$VARS")

[ -z "$abb_delete" ] && exit 1

#######################################
# remove button from filament selector #
#######################################

awk -v abb="$abb_delete" -v indent="$INDENT" '
/action:prompt_group_begin/ {
  print
  in_group=1
  next
}
/action:prompt_group_end/ {
  in_group=0
  print
  next
}
in_group && $0 ~ "ABB="abb {
  next
}
{ print }
' "$CFG" > "$TMP_CFG"

mv "$TMP_CFG" "$CFG"

#################################
# purge filament variables file #
#################################

awk -v abb="$abb_delete" '
$0 ~ "^"abb {
  next
}
{ print }
' "$VARS" > "$TMP_VARS"

mv "$TMP_VARS" "$VARS"
