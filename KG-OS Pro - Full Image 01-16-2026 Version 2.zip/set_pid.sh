#!/bin/bash

VAR=/home/sonic/klipper/variables.cfg
EXT=/home/sonic/printer_data/config/ext_pid.cfg
BED=/home/sonic/printer_data/config/bed_pid.cfg

# read active extruder PID values
ext_kp=$(awk '/^act_ext_pid_kp =/ {print $3}' "$VAR")
ext_ki=$(awk '/^act_ext_pid_ki =/ {print $3}' "$VAR")
ext_kd=$(awk '/^act_ext_pid_kd =/ {print $3}' "$VAR")

# read active bed PID values
bed_kp=$(awk '/^act_bed_pid_kp =/ {print $3}' "$VAR")
bed_ki=$(awk '/^act_bed_pid_ki =/ {print $3}' "$VAR")
bed_kd=$(awk '/^act_bed_pid_kd =/ {print $3}' "$VAR")

# write extruder PID config
sed -i "s/^pid_Kp:.*/pid_Kp: $ext_kp/" "$EXT"
sed -i "s/^pid_Ki:.*/pid_Ki: $ext_ki/" "$EXT"
sed -i "s/^pid_Kd:.*/pid_Kd: $ext_kd/" "$EXT"

# write bed PID config
sed -i "s/^pid_Kp:.*/pid_Kp: $bed_kp/" "$BED"
sed -i "s/^pid_Ki:.*/pid_Ki: $bed_ki/" "$BED"
sed -i "s/^pid_Kd:.*/pid_Kd: $bed_kd/" "$BED"
