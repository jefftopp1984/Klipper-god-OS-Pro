#!/bin/sh

VARS="/home/sonic/klipper/variables.cfg"
CFG="/home/sonic/printer_data/config/kg_os_pro_filupd.cfg"

act_ext_target=$(grep '^act_ext_target = ' "$VARS" | awk '{print $3}')
act_bed_target=$(grep '^act_bed_target = ' "$VARS" | awk '{print $3}')
act_bottom_flow=$(grep '^act_bottom_flow = ' "$VARS" | awk '{print $3}')
act_solid_flow=$(grep '^act_solid_flow = ' "$VARS" | awk '{print $3}')
act_overhang_flow=$(grep '^act_overhang_flow = ' "$VARS" | awk '{print $3}')
act_norm_fan=$(grep '^act_norm_fan = ' "$VARS" | awk '{print $3}')
act_solid_fan=$(grep '^act_solid_fan = ' "$VARS" | awk '{print $3}')
act_bridge_fan=$(grep '^act_bridge_fan = ' "$VARS" | awk '{print $3}')
act_overhang_fan=$(grep '^act_overhang_fan = ' "$VARS" | awk '{print $3}')

sed -Ei '/# Filament Update Section Start/,/# Filament Update Section End/{
s@(\{% set ext_target = params\.EXT_TEMP\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_ext_target"'\2@
s@(\{% set bed_target = params\.BED_TEMP\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_bed_target"'\2@
s@(\{% set bottom_flow = params\.BOTTOM_FLOW\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_bottom_flow"'\2@
s@(\{% set solid_flow = params\.SOLID_FLOW\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_solid_flow"'\2@
s@(\{% set overhang_flow = params\.OVERHANG_FLOW\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_overhang_flow"'\2@
s@(\{% set norm_fan = params\.NORM_FAN\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_norm_fan"'\2@
s@(\{% set solid_fan = params\.SOLID_FAN\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_solid_fan"'\2@
s@(\{% set bridge_fan = params\.BRIDGE_FAN\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_bridge_fan"'\2@
s@(\{% set overhang_fan = params\.OVERHANG_FAN\|default\()[0-9]+(\)\|int != 0 %})@\1'"$act_overhang_fan"'\2@
}' "$CFG"
