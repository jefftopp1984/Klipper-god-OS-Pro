#!/bin/bash

VAR=/home/sonic/klipper/variables.cfg
SNAPSHOT=/home/sonic/printer_data/config/klippy_snap.log
MOONRAKER="http://localhost:7125/printer/gcode/script?async=true"

# extract new extruder PID values from the snapshot
kp=$(grep "save_config: set \[heater_bed\] pid_Kp = " "$SNAPSHOT" | tail -n 1 | awk '{print $NF}')
ki=$(grep "save_config: set \[heater_bed\] pid_Ki = " "$SNAPSHOT" | tail -n 1 | awk '{print $NF}')
kd=$(grep "save_config: set \[heater_bed\] pid_Kd = " "$SNAPSHOT" | tail -n 1 | awk '{print $NF}')

# read active filament selector (FORMAT: act_fil = X)
act_fil=$(awk -F' = ' '/^act_fil =/ {print $2}' "$VAR")

case "$act_fil" in
  1) pfx="asa" ;;
  2) pfx="asacf" ;;
  3) pfx="abs" ;;
  4) pfx="petg" ;;
  *) exit 1 ;;
esac

curl -s -X POST --data-urlencode "script=SAVE_VARIABLE VARIABLE=${pfx}_bed_kp VALUE=$kp" "$MOONRAKER" &
curl -s -X POST --data-urlencode "script=SAVE_VARIABLE VARIABLE=${pfx}_bed_ki VALUE=$ki" "$MOONRAKER" &
curl -s -X POST --data-urlencode "script=SAVE_VARIABLE VARIABLE=${pfx}_bed_kd VALUE=$kd" "$MOONRAKER" &

# remove the snapshot file
rm /home/sonic/printer_data/config/klippy_snap.log
